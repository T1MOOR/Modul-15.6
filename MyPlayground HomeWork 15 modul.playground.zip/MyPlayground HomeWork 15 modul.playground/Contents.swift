import UIKit
import Foundation

var greeting = "Hello, playground"

// Создайте перечисление для ошибок. Добавьте в него 3 кейса
enum CustomError: Error {
    case badRequest
    case notFound
    case inrenalServerError
}


//Далее создайте переменную, которая будет хранить в себе какую-либо ошибку (400 или 404 или 500). И при помощи do-catch сделайте обработку ошибок перечисления. Для каждой ошибки должно быть выведено сообщение в консоль.
var badRequest: Bool = false
var notFound: Bool = true
var inrenalServerError: Bool = false

do {
    if badRequest {
        throw CustomError.badRequest
    }
    if notFound {
        throw CustomError.notFound
    }
    if inrenalServerError {
        throw CustomError.inrenalServerError
    }
} catch CustomError.badRequest {
    print("некорректный запрос")
} catch CustomError.notFound {
    print ("не найдено")
} catch CustomError.inrenalServerError {
    print ("внутренняя ошибка сервера")
}

//Теперь добавьте проверку переменных в генерирующую функцию и обрабатывайте её!
func someFunc() throws {
    if badRequest { throw CustomError.badRequest }
    if notFound { throw CustomError.notFound }
    if inrenalServerError { throw CustomError.inrenalServerError }
}

do {
    try someFunc()
} catch CustomError.badRequest {
    print("некорректный запрос")
} catch CustomError.notFound {
    print ("не найдено")
} catch CustomError.inrenalServerError {
    print ("внутренняя ошибка сервера")
}

//Напишите функцию, которая будет принимать на вход два разных типа и проверять: если типы входных значений одинаковые, то вывести сообщение “Yes”, в противном случае — “No”.


func someFunc<T, E>(a: T, b: E) -> Void {
    if type(of: T.self) == type(of: E.self) {
        print("Yes")
    } else {
        print("No")
    }
}
 
someFunc(a: "65", b: 4)


//Реализуйте то же самое, но если тип входных значений различается, выбросите исключение. Если тип одинаковый — тоже выбросите исключение, но оно уже будет говорить о том, что типы одинаковые. Не бойтесь этого. Ошибки — это не всегда про плохой результат.

enum SomeErrors: Error {
    case inputTypeIsDifferent
    case inputTypeIsTheSame
}

//func someFunc2<T, E>(a: T, b: E) -> SomeErrors {
//    if type(of: T.self) == type(of: E.self) {
//        return SomeErrors.inputTypeIsTheSame
//    } else {
//        return SomeErrors.inputTypeIsDifferent
//    }
//}
//
//print(someFunc2(a: 43, b: 43))


func someFunc3<T, E>(a: T, b: E) throws {
    if type(of: T.self) == type(of: E.self) {throw SomeErrors.inputTypeIsTheSame }
    
    if type(of: T.self) != type(of: E.self) {throw SomeErrors.inputTypeIsDifferent}
}

do {
    try someFunc3(a: 55, b: 45)
} catch SomeErrors.inputTypeIsTheSame {
    print ("input type is the same")
} catch SomeErrors.inputTypeIsDifferent {
    print("input type is different")
}


//Напишите функцию, которая принимает на вход два любых значения и сравнивает их при помощи оператора равенства ==
func someFunc4<T:Equatable>(a: T, b: T)  {
    if a == b {
        print("\(a) equals \(b)")
    } else {
       print("\(a) is not equal to \(b)")
    }
}

someFunc4(a: 4, b: 4)
